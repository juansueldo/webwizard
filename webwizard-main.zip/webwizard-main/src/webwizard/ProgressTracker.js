// Modificaciones y nuevos métodos para ProgressTracker.js

export class ProgressTracker {
    constructor(logger, nodeManager, connectionManager) {
        this.logger = logger;
        this.nodeManager = nodeManager;
        this.connectionManager = connectionManager;
    }

    // Método existente - mantener como está
    getProgressPath() {
        try {
            const startNode = this.nodeManager.getNodeByType('start');
            if (!startNode) {
                this.logger.warn('ProgressTracker', 'getProgressPath', 'No start node found');
                return [];
            }

            const path = [];
            this.traverseNodes(startNode.id, path, new Set(), null);
            
            return path.filter(step => step.type !== 'start' && step.type !== 'hidden');
        } catch (error) {
            this.logger.error('ProgressTracker', 'getProgressPath', 'Error getting progress path', {
                error: error.message
            });
            return [];
        }
    }

    // NUEVO: Método para obtener path dinámico basado en selecciones actuales
    getDynamicProgressPath(currentNodeId, currentSelections) {
        try {
            const startNode = this.nodeManager.getNodeByType('start');
            if (!startNode) {
                this.logger.warn('ProgressTracker', 'getDynamicProgressPath', 'No start node found');
                return [];
            }

            const path = [];
            this.traverseNodesWithSelections(startNode.id, path, new Set(), currentSelections, currentNodeId);
            
            const filteredPath = path.filter(step => step.type !== 'start' && step.type !== 'hidden');
            
            this.logger.debug('ProgressTracker', 'getDynamicProgressPath', 'Dynamic path calculated', {
                pathLength: filteredPath.length,
                currentNodeId,
                selectionsCount: currentSelections.size
            });
            
            return filteredPath;
        } catch (error) {
            this.logger.error('ProgressTracker', 'getDynamicProgressPath', 'Error getting dynamic progress path', {
                error: error.message,
                currentNodeId
            });
            return this.getProgressPath(); // Fallback al path estático
        }
    }

    // NUEVO: Método para atravesar nodos considerando selecciones actuales
    traverseNodesWithSelections(nodeId, path, visited, currentSelections, targetNodeId) {
        if (visited.has(nodeId) || path.length > 50) { // Prevenir loops infinitos
            return false;
        }

        visited.add(nodeId);
        const node = this.nodeManager.getNode(nodeId);
        if (!node) return false;

        // Agregar nodo actual al path
        path.push({
            id: node.id,
            title: this.getNodeDisplayTitle(node),
            type: node.type
        });

        // Si llegamos al nodo objetivo, detener la búsqueda
        if (nodeId === targetNodeId) {
            return true;
        }

        // Determinar el siguiente nodo basado en el tipo y selecciones actuales
        const nextNodeId = this.getNextNodeWithSelections(node, currentSelections);
        
        if (nextNodeId) {
            const found = this.traverseNodesWithSelections(nextNodeId, path, new Set(visited), currentSelections, targetNodeId);
            if (found) return true;
        }

        // Si no encontramos el nodo objetivo en este path, remover el nodo actual y continuar
        if (nodeId !== targetNodeId) {
            path.pop();
        }

        return false;
    }

    // NUEVO: Método para determinar el siguiente nodo basado en selecciones
    getNextNodeWithSelections(node, currentSelections) {
        const nodeSelection = currentSelections.get(node.id);
        
        // Para nodos select y radio con selección actual
        if (['select', 'radio'].includes(node.type) && nodeSelection) {
            const nextNodeFromOption = this.getNextNodeFromSelectedOption(node, nodeSelection.selectedValue);
            if (nextNodeFromOption) {
                return nextNodeFromOption;
            }
        }

        // Buscar conexión de output general
        const generalConnections = this.connectionManager.getConnectionsFrom(node.id, 'output');
        if (generalConnections.length > 0) {
            return generalConnections[0].to;
        }

        // Para nodos select y radio sin selección actual, tomar la primera opción por defecto
        if (['select', 'radio'].includes(node.type) && node.options && node.options.length > 0) {
            const defaultNextNode = this.getNextNodeFromSelectedOption(node, node.options[0].value);
            if (defaultNextNode) {
                return defaultNextNode;
            }
        }

        return null;
    }

    // NUEVO: Método para obtener el siguiente nodo desde una opción seleccionada
    getNextNodeFromSelectedOption(node, selectedValue) {
        if (!node.options || !selectedValue) return null;

        // Encontrar el índice de la opción seleccionada
        const selectedOptionIndex = node.options.findIndex(opt => opt.value === selectedValue);
        
        if (selectedOptionIndex === -1) return null;

        // Buscar conexión desde esa opción específica
        const optionConnections = this.connectionManager.getConnectionsFrom(node.id, 'option', selectedOptionIndex);
        
        if (optionConnections.length > 0) {
            return optionConnections[0].to;
        }

        return null;
    }

    // Método existente modificado para ser más robusto
    traverseNodes(nodeId, path, visited, maxDepth = 50) {
        if (visited.has(nodeId) || path.length >= maxDepth) {
            return;
        }

        visited.add(nodeId);
        const node = this.nodeManager.getNode(nodeId);
        if (!node) return;

        path.push({
            id: node.id,
            title: this.getNodeDisplayTitle(node),
            type: node.type
        });

        // Buscar conexiones desde este nodo
        let nextConnections = this.connectionManager.getConnectionsFrom(node.id, 'output');
        
        if (nextConnections.length > 0) {
            this.traverseNodes(nextConnections[0].to, path, new Set(visited), maxDepth);
        } else if (['select', 'radio'].includes(node.type) && node.options && node.options.length > 0) {
            // Si no hay conexión general, buscar conexión desde la primera opción
            const firstOptionConnections = this.connectionManager.getConnectionsFrom(node.id, 'option', 0);
            if (firstOptionConnections.length > 0) {
                this.traverseNodes(firstOptionConnections[0].to, path, new Set(visited), maxDepth);
            }
        }
    }

    // Método existente - mantener como está
    getCurrentStepIndex(currentNodeId, progressPath) {
        if (!progressPath || progressPath.length === 0) return -1;
        
        const index = progressPath.findIndex(step => step.id === currentNodeId);
        return index >= 0 ? index : -1;
    }

    // NUEVO: Método mejorado para obtener el título de display del nodo
    getNodeDisplayTitle(node) {
        if (!node) return 'Unknown Step';
        
        // Prioridad: content > title > type con ID
        if (node.content && node.content.trim()) {
            return this.truncateTitle(node.content);
        }
        
        if (node.title && node.title.trim()) {
            return this.truncateTitle(node.title);
        }
        
        // Fallback basado en tipo
        const typeLabels = {
            'start': 'Start',
            'text': 'Text Input',
            'email': 'Email',
            'password': 'Password',
            'number': 'Number',
            'textarea': 'Text Area',
            'select': 'Selection',
            'radio': 'Options',
            'checkbox': 'Checkboxes',
            'file': 'File Upload',
            'range': 'Range',
        };
        
        const typeLabel = typeLabels[node.type] || 'Step';
        return `${typeLabel}`;
    }

    // NUEVO: Método auxiliar para truncar títulos largos
    truncateTitle(title) {
        if (!title) return 'Step';
        
        const maxLength = 20;
        if (title.length <= maxLength) return title;
        
        return title.substring(0, maxLength - 3) + '...';
    }

    // NUEVO: Método para validar la consistencia del path de progreso
    validateProgressPath(path) {
        if (!Array.isArray(path)) return false;
        
        return path.every(step => 
            step && 
            typeof step === 'object' && 
            step.id && 
            step.title && 
            step.type
        );
    }

    // NUEVO: Método para obtener estadísticas del progreso
    getProgressStats(currentNodeId, progressPath) {
        if (!progressPath || progressPath.length === 0) {
            return {
                totalSteps: 0,
                currentStep: 0,
                completedSteps: 0,
                remainingSteps: 0,
                progressPercentage: 0
            };
        }

        const currentIndex = this.getCurrentStepIndex(currentNodeId, progressPath);
        const totalSteps = progressPath.length;
        const currentStep = currentIndex >= 0 ? currentIndex + 1 : 0;
        const completedSteps = Math.max(0, currentIndex);
        const remainingSteps = Math.max(0, totalSteps - currentStep);
        const progressPercentage = totalSteps > 0 ? Math.round((completedSteps / totalSteps) * 100) : 0;

        return {
            totalSteps,
            currentStep,
            completedSteps,
            remainingSteps,
            progressPercentage
        };
    }
}